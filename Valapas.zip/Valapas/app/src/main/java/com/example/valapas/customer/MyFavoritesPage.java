package com.example.valapas.customer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.valapas.R;

public class MyFavoritesPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_favorites_page);
    }
}
