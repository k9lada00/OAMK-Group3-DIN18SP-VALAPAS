package com.example.valapas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.valapas.company.CreateCompany;
import com.example.valapas.customer.CreateCustomer;

public class SignupPage extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_page);
    }

    public void selectBackBtn(View v)
    {
        Intent i = new Intent (this, MainActivity.class);
        startActivity(i);
    }

    public void selectCustomer(View v)
    {
        Intent i = new Intent (this, CreateCustomer.class);
        startActivity(i);
    }

    public void selectCompany(View v)
    {
        Intent i = new Intent (this, CreateCompany.class);
        startActivity(i);
    }
}
