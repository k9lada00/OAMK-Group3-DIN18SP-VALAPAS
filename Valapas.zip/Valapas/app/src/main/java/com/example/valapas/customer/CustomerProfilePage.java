package com.example.valapas.customer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.valapas.R;

public class CustomerProfilePage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_profile_page);
    }
}
